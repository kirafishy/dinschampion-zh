ZhSmokeGameSystem overrides GameSystem
{
	FontTinyDefault		ZhSmoke8
	FontVerySmallDefault		ZhSmoke10
	FontSmallDefault		ZhSmoke12
	FontDefault		ZhSmoke16
	FontLargeDefault		ZhSmoke20
	FontVeryLargeDefault		ZhSmoke24
	FontCriticalHit		ZhSmoke16
	FontXP		ZhSmoke20
	FontItem		ZhSmoke12
	FontVeryLargeDefault2		ZhSmoke32
	FontVeryLargeDefault3		ZhSmoke40
	FontVeryLargeDefault4		ZhSmoke48
}
